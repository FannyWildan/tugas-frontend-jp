package com.example.tugasfront_endjetpackcompose_fannywildanfuady

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
@Composable
fun AboutScreen() {
    Column {
        TopAppBar(title = { Text("About") })
        Text("Nama: Fanny Wildan Fuady")
        Text("Email: wildanfuady30@gmail.com")
        Text("Kampus: Universitas Jember")
        Text("Jurusan: Teknologi Informasi")
    }
}