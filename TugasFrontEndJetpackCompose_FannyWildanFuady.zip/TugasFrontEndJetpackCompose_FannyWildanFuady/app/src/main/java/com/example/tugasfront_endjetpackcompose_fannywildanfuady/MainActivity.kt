package com.example.tugasfront_endjetpackcompose_fannywildanfuady

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.jetpackcomposeapp.ui.theme.JetpackComposeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JetpackComposeAppTheme {
                MyApp()
            }
        }
    }
}

@Composable
fun MyApp() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.List.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.List.route) { ListScreen(navController) }
            composable(Screen.Grid.route) { GridScreen(navController) }
            composable(Screen.About.route) { AboutScreen() }
            composable(Screen.Detail.route + "/{itemId}") { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId")
                DetailScreen(itemId = itemId)
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavController) {
    BottomNavigation {
        BottomNavigationItem(
            icon = { Icon(Icons.Filled.List, contentDescription = "List") },
            label = { Text("List") },
            selected = false,
            onClick = { navController.navigate(Screen.List.route) }
        )
        BottomNavigationItem(
            icon = { Icon(Icons.Filled.Grid, contentDescription = "Grid") },
            label = { Text("Grid") },
            selected = false,
            onClick = { navController.navigate(Screen.Grid.route) }
        )
        BottomNavigationItem(
            icon = { Icon(Icons.Filled.Info, contentDescription = "About") },
            label = { Text("About") },
            selected = false,
            onClick = { navController.navigate(Screen.About.route) }
        )
    }
}

object Screen {
    val List = ScreenItem("list")
    val Grid = ScreenItem("grid")
    val About = ScreenItem("about")
    val Detail = ScreenItem("detail")

    data class ScreenItem(val route: String)
}